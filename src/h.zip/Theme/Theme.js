export default {
  black: "rgb(42,42,42)",
  orange: "rgb(247,190,88)",
  white: "rgb(245,245,245)",
};
